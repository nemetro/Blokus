We have submitted two jar files called "Blokus" and "StartServer" for our 
project. We also have including all source code and structure.

To run our game simply run the Blokus.jar
-From here you can play our game locally, do the tutorial, read the rules,
and look at the about pages.

If you want to play over our simulated server you must first launch the
StartServer.jar, this will open up a simulated terminal that displays 
the IP address of the server. Then you can launch the Blokus.jar and hit
the play online button to play over the server. You will be prompted for
the number of players and a username, simply create a username and password
and then hit the create button to play. If you already created an account
you can sign in with that one.

**Our program uses a database so if you want to run it just by compiling the 
code you must include the sqllite external library we have attached.
